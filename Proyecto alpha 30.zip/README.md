# ProjectoAlpha30

Proyecto final de la materia "Programación de la calidad". Favor de ignorar al menos que sea mi maestro o compañero.
Atención: Para poder utilizar bien el Code se necesita como obligación un server propio.
