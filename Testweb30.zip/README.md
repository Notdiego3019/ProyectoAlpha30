# ProjectoAlpha30

Projecto final de la materia "Programacion de la calidad".
Favor de ignorar a menos que sea mi maestro o compañero.
